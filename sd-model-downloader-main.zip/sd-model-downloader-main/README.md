# sd-model-downloader
SD Web UI Extension to Download Model from URL

# update fix
if u want to use on your local (not colab)
change directory ("root" and "sd_path") in  model-downloader.py

example:<br>
`root = "C:" or "D:" etc`<br>
`sd_path = "/your_sd_repo_folder"`


# This Extension Only Work on Google Colab

To install it, clone the repo into the `extensions` directory and run colab:<br>
`!git clone https://github.com/Iyashinouta/sd-model-downloader /content/stable-diffusion-webui/extensions/sd-model-downloader`<br>
or Install from SD Webui:<br>
install from URL, and Paste Link `https://github.com/Iyashinouta/sd-model-downloader`
